# Licenses for sound samples used in tests

loop_amen_full.wav
source: https://freesound.org/people/gowers/sounds/202537/
license: https://creativecommons.org/publicdomain/zero/1.0/

loop_amen.wav
source: https://freesound.org/people/Dolfeus/sounds/43389/
license: https://creativecommons.org/publicdomain/zero/1.0/

french_house_thing.wav
source: Xavier Riley (original composition)
license: https://creativecommons.org/publicdomain/zero/1.0/

acappella.mp3
source: https://freesound.org/people/juskiddink/sounds/121769/
license: https://creativecommons.org/publicdomain/zero/1.0/
