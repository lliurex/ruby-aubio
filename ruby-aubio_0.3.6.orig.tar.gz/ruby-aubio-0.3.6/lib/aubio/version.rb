# frozen_string_literal: true

module Aubio
  VERSION = '0.3.6'
end
